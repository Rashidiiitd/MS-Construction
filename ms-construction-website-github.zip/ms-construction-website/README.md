# MS Construction Website

A responsive static website for MS Construction, the new business name following Meraki Developer.

## Files
- `index.html` — page structure and content
- `styles.css` — responsive layout, visual design, and animations
- `script.js` — mobile navigation, reveal animations, back-to-top, and demo form validation
- `assets/ms-construction-logo.png` — custom MS Construction logo

## Preview locally
Open `index.html` in Chrome. The page uses online Unsplash images and Google Fonts, so an internet connection helps the visuals load.

## Open in GitHub Codespaces
1. Upload these files to a GitHub repository (keep the `assets` folder).
2. Open the repository in Codespaces.
3. Open `index.html` in the editor.
4. To preview with a local web server, run `python3 -m http.server 8000` in the terminal.
5. In Codespaces, choose the forwarded port 8000 and open the preview.

## Publish with GitHub Pages
1. Push the project to a GitHub repository.
2. Go to repository Settings → Pages.
3. Choose Deploy from a branch, select `main` and `/ (root)`, then save.
4. Wait for the Pages deployment to finish and open the URL shown there.

## Before production
- The contact form is a front-end demo only. It does not submit or store data. Connect a secure form provider or backend before expecting online enquiries.
- Replace representative stock photos with approved real project photographs where available.
- Confirm final business contact/address details and any legal/business registration details before publishing.
- Only add project references, certifications, ownership claims, and guarantees that the business can substantiate.
- Current contact number intentionally uses only: 8534915638.
